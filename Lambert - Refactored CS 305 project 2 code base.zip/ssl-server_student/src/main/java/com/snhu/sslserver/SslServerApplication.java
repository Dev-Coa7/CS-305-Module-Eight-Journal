package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ServerController {
    // This method calculates and returns the hash value for the data string
    @RequestMapping("/hash")
    public String myHash() {
        String data = "Benjamin Lambert";
        String algorithm = "SHA-256";
        String checksum = calculateHash(data, algorithm);

        return "<p>Data: " + data + "</p>" +
               "<p>Algorithm Cipher Used: " + algorithm + "</p>" +
               "<p>Checksum: " + checksum + "</p>";
    }

    // Helper method to calculate the hash
    private String calculateHash(String data, String algorithm) {
        try {
            MessageDigest digest = MessageDigest.getInstance(algorithm);
            byte[] hashBytes = digest.digest(data.getBytes());

            // Convert byte array into a hexadecimal string
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            return "Error: Hash algorithm not supported";
        }
    }
}

